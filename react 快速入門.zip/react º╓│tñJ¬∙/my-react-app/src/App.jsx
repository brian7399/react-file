import './App.css';

const MyComponent = () => {
  return <h1>你好</h1>;
}

function App() {
  const text = "Hello world";
  const handleClick = ()=>{
    alert("hello")
  }
  return (
    <>
      <input type="text" placeholder={text}/>
      <button onClick={handleClick}>我是按鈕</button>
      <h1>{text.toUpperCase()}</h1>
      <MyComponent /><MyComponent /><MyComponent />
    </>
  );
}

export default App;
